<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Warehouse Bond System</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">
    <nav class="bg-blue-600 p-4 text-white shadow-lg mb-8">
        <div class="container mx-auto flex justify-between">
            <h1 class="font-bold text-xl">Construction Warehouse</h1>
            <div>
                <a href="{{ route('dashboard') }}" class="mr-4 hover:underline">Dashboard</a>
                <a href="/bonds/create" class="bg-white text-blue-600 px-4 py-2 rounded shadow">+ New Bond</a>
            </div>
        </div>
    </nav>
    <div class="container mx-auto px-4">
        @yield('content')
    </div>
</body>
</html>