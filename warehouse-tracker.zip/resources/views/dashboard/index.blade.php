@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Bond Management Dashboard</h5>
        </div>
        
        <div class="card-body">
            <!-- Bulk Action Toolbar -->
            <div class="row mb-3 g-2 align-items-center">
                <div class="col-auto">
                    <select id="stack_id" class="form-select form-select-sm">
                        <option value="">-- Assign to Stack --</option>
                        @foreach($stacks as $stack)
                            <option value="{{ $stack->id }}">{{ $stack->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-auto">
                    <button id="assignBtn" class="btn btn-primary btn-sm">Apply to Selected</button>
                </div>
                <div class="col-auto">
                    <div id="ajax-loader" class="spinner-border spinner-border-sm text-primary d-none"></div>
                    <span id="response-msg" class="small ms-2"></span>
                </div>
            </div>

            <!-- Inject the Table Partial -->
            @include('dashboard.partials._bonds_table')
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Select/Deselect All logic
    $(document).on('click', '#selectAll', function() {
        $('.bond-checkbox').prop('checked', this.checked);
    });

    // Handle Bulk Assignment via AJAX
    $('#assignBtn').on('click', function() {
        const selectedIds = [];
        const stackId = $('#stack_id').val();

        $('.bond-checkbox:checked').each(function() {
            selectedIds.push($(this).val());
        });

        if (selectedIds.length === 0) {
            alert('Please select at least one bond.');
            return;
        }

        if (!stackId) {
            alert('Please select a target stack.');
            return;
        }

        $.ajax({
            url: "{{ route('bonds.bulkAssign') }}",
            method: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                bond_ids: selectedIds,
                stack_id: stackId
            },
            beforeSend: function() {
                $('#assignBtn').prop('disabled', true);
                $('#ajax-loader').removeClass('d-none');
                $('#response-msg').text('');
            },
            success: function(response) {
                $('#response-msg').removeClass('text-danger').addClass('text-success').text(response.message);
                
                // Visual feedback: Update row appearance or remove
                selectedIds.forEach(id => {
                    $(`#bond-row-${id}`).fadeOut(400, function() {
                        $(this).remove();
                    });
                });
                
                $('#selectAll').prop('checked', false);
            },
            error: function(xhr) {
                $('#response-msg').addClass('text-danger').text('An error occurred during assignment.');
                console.error(xhr.responseText);
            },
            complete: function() {
                $('#assignBtn').prop('disabled', false);
                $('#ajax-loader').addClass('d-none');
            }
        });
    });
});
</script>
@endpush