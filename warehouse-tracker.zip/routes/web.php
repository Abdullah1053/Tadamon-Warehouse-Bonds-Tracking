<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BondController;
use App\Http\Controllers\StackController;

// Bond Routes
Route::get('/', [StackController::class, 'index'])->name('dashboard');
Route::get('/bonds/create', [BondController::class, 'create']);
Route::post('/bonds/store', [BondController::class, 'store']);
Route::post('/stacks/create', [StackController::class, 'createStack']);
Route::get('/stacks/export/{stack}', [StackController::class, 'export']);
Route::get('/dashboard', [BondController::class, 'index'])->name('dashboard');
Route::post('/bonds/bulk-assign', [BondController::class, 'bulkAssign'])->name('bonds.bulkAssign');