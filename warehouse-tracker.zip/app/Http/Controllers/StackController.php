<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exports\StackExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Models\Stack;
use App\Models\Bond;

class StackController extends Controller
{

public function index() {
    $stacks = Stack::latest()->get();
    return view('dashboard', compact('stacks'));
}    

public function createStack(Request $request) 
{
    // 1. Create the Stack record
    $stack = Stack::create([
        'stack_name'   => $request->stack_name,
        'start_serial' => $request->start,
        'end_serial'   => $request->end,
    ]);

    // 2. Link all bonds in that range to this stack
    Bond::whereBetween('bond_serial', [$request->start, $request->end])
        ->update(['stack_id' => $stack->id]);

    return back()->with('success', 'Stack Created and Bonds Linked.');
}


public function export(Stack $stack) 
{
    return Excel::download(new StackExport($stack), "Stack_{$stack->stack_name}.xlsx");
}
}
