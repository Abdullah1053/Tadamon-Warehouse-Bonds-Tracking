<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bond;
use App\Models\BondItem;
use DB;
use App\Models\Stack;

class BondController extends Controller
{
    public function store(Request $request)
    {
        return DB::transaction(function () use ($request) {
            // 1. Create the Bond Header
            $bond = Bond::create([
                'bond_serial'    => $request->bond_serial,
                'date'           => $request->date,
                'operation_name' => $request->operation_name,
                'received_from'  => $request->received_from,
                'car_number'     => $request->car_number,
            ]);

            // 2. Create the Bond Items (Tools)
            foreach ($request->items as $item) {
                if (!empty($item['description'])) {
                    $bond->items()->create([
                        'item_description' => $item['description'],
                        'quantity'         => $item['quantity'],
                    ]);
                }
            }

            return response()->json(['success' => true, 'next_serial' => $bond->bond_serial + 1]);
        });
    }

    public function create() {
    // Get the last serial to help the user
    $lastSerial = Bond::max('bond_serial') ?? 3000; 
    return view('bonds.create', ['nextSerial' => $lastSerial + 1]);
}

 public function index()
    {
        $bonds = Bond::whereNull('stack_id')->get(); // Show only unassigned
        $stacks = Stack::all();
        
        return view('dashboard.index', compact('bonds', 'stacks'));
    }
        public function bulkAssign(Request $request)
    {
        $request->validate([
            'bond_ids' => 'required|array',
            'stack_id' => 'required|exists:stacks,id',
        ]);

        try {
            // Bulk update bonds to the selected stack
            Bond::whereIn('id', $request->bond_ids)
                ->update(['stack_id' => $request->stack_id]);

            return response()->json([
                'status' => 'success',
                'message' => count($request->bond_ids) . ' bonds successfully assigned.'
            ]);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error'], 500);
        }
    }
}